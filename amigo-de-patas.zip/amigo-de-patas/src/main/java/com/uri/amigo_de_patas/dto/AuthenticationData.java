package com.uri.amigo_de_patas.dto;

public record AuthenticationData(String email, String password) {

}
