package com.uri.amigo_de_patas.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class UserDTO {
    private String nome;
    private String email;
    private String senha;
}
