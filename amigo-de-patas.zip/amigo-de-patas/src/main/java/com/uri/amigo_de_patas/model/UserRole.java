package com.uri.amigo_de_patas.model;

public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN
}
