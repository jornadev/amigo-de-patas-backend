package com.uri.amigo_de_patas.security;

public record DadosTokenJWT(String token) {

}
