package com.uri.amigo_de_patas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigoDePatasApplicationTests {

	@Test
	void contextLoads() {
	}

}
