package com.uri.amigo_de_patas.model;

public enum ApplicationStatus {
    PENDENTE,
    ACEITO,
    RECUSADO
}


